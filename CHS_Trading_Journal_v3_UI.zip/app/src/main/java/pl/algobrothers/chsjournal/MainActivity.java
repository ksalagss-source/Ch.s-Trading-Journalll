package pl.algobrothers.chsjournal;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
  final int bg=Color.rgb(6,12,25), panel=Color.rgb(15,27,47), blue=Color.rgb(44,123,245), white=Color.WHITE, muted=Color.rgb(142,160,187), green=Color.rgb(38,218,157), red=Color.rgb(255,90,117);
  LinearLayout root,body,nav; JSONArray trades=new JSONArray(); int screen=0;
  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);load();show(0);}
  void load(){try{trades=new JSONArray(getPreferences(0).getString("trades","[]"));}catch(Exception e){trades=new JSONArray();}}
  void save(){getPreferences(0).edit().putString("trades",trades.toString()).apply();}
  GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
  GradientDrawable outlined(int color,int radius){GradientDrawable d=shape(color,radius);d.setStroke(dp(1),0xff243958);return d;}
  GradientDrawable glow(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff12365f,0xff0d1c34,0xff101b30});d.setCornerRadius(dp(22));d.setStroke(dp(1),0xff2d5481);return d;}
  TextView chip(String s,int fg,int back){TextView t=txt(s,11,fg,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(11),dp(7),dp(11),dp(7));t.setBackground(shape(back,25));return t;}
  void marginBottom(LinearLayout parent,View v,int bottom){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(bottom);parent.addView(v,lp);}
  LinearLayout statCard(String title,String value,String foot,int valueColor){LinearLayout c=col();pad(c,15);c.setBackground(outlined(panel,18));label(c,title.toUpperCase(new Locale("pl","PL")),10,muted,true);gap(c,9);label(c,value,23,valueColor,true);gap(c,6);label(c,foot,11,muted,false);return c;}
  void twoStats(LinearLayout parent,LinearLayout left,LinearLayout right){LinearLayout r=row();LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,-2,1);a.rightMargin=dp(10);r.addView(left,a);r.addView(right,new LinearLayout.LayoutParams(0,-2,1));marginBottom(parent,r,10);}
  void sectionTitle(LinearLayout parent,String s,String sub){label(parent,s,19,white,true);if(sub!=null){gap(parent,4);label(parent,sub,12,muted,false);}gap(parent,14);}

  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  void add(LinearLayout l,View v){l.addView(v);}
  void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
  void label(LinearLayout l,String s,int size,int color,boolean bold){add(l,txt(s,size,color,bold));}
  LinearLayout card(LinearLayout parent){LinearLayout c=col();pad(c,16);c.setBackground(outlined(panel,18));add(parent,c);gap(parent,12);return c;}
  void button(LinearLayout parent,String s,Runnable action){TextView b=txt(s,15,white,true);b.setGravity(Gravity.CENTER);pad(b,14);b.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xff2675ed,0xff4e9bff}) {{setCornerRadius(dp(14));}});add(parent,b);b.setOnClickListener(v->action.run());}
  double val(JSONObject j,String k){return j.optDouble(k,0);}
  String money(double n){return String.format(new Locale("pl","PL"),"%+.2f zł",n);}
  void show(int tab){
    screen=tab;root=col();root.setBackgroundColor(bg);setContentView(root);
    LinearLayout head=row();head.setPadding(dp(19),dp(18),dp(19),dp(12));add(root,head);
    LinearLayout brand=col();head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
    label(brand,"CH.S  /  ALGOBROTHERS",19,white,true);gap(brand,3);label(brand,"TRADING JOURNAL   •   OFFLINE",10,muted,true);
    add(head,chip("●  LOCAL",green,0xff123b39));
    View line=new View(this);line.setBackgroundColor(0xff1d2c45);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
    body=col();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body.setPadding(dp(17),dp(20),dp(17),dp(20));
    if(tab==0)dashboard();else if(tab==1)journal();else if(tab==2)analysis();else more();
    nav=row();nav.setPadding(dp(7),dp(10),dp(7),dp(12));nav.setBackgroundColor(0xff0c1729);add(root,nav);
    String[] names={"⌂\nPULPIT","▤\nDZIENNIK","▥\nANALIZA","☰\nWIĘCEJ"};
    for(int i=0;i<4;i++){final int ix=i;TextView n=txt(names[i],11,i==tab?0xff6fb0ff:muted,i==tab);n.setGravity(Gravity.CENTER);n.setLineSpacing(dp(4),1f);if(i==tab)n.setBackground(shape(0xff142a48,13));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(54),1);lp.leftMargin=dp(3);lp.rightMargin=dp(3);nav.addView(n,lp);n.setOnClickListener(v->show(ix));}
  }
  void dashboard(){
    label(body,"Przegląd wyników",26,white,true);gap(body,5);label(body,"Twój trading. Twoje decyzje. Twoje liczby.",12,muted,false);gap(body,18);
    int wins=0,loss=0;double total=0,grossWin=0,grossLoss=0;
    for(int i=0;i<trades.length();i++){JSONObject j=trades.optJSONObject(i);if(j==null)continue;double p=val(j,"pnl");total+=p;if(p>0){wins++;grossWin+=p;}if(p<0){loss++;grossLoss-=p;}}
    LinearLayout hero=col();pad(hero,20);hero.setBackground(glow());marginBottom(body,hero,13);
    LinearLayout title=row();add(hero,title);TextView titleTxt=txt("ŁĄCZNY WYNIK NETTO",11,0xffa9c5e7,true);title.addView(titleTxt,new LinearLayout.LayoutParams(0,-2,1));add(title,chip("↗  P&L",0xff9fc9ff,0xff214977));gap(hero,14);
    label(hero,money(total),34,total>=0?green:red,true);gap(hero,8);label(hero,"Wynik z "+trades.length()+" zapisanych transakcji",12,0xffb1c6e3,false);
    twoStats(body,statCard("Win rate",wins+loss==0?"—":String.format(Locale.US,"%.1f%%",100.0*wins/(wins+loss)),"Skuteczność",white),statCard("Profit factor",grossLoss==0?"—":String.format(Locale.US,"%.2f",grossWin/grossLoss),"Zysk / strata",white));
    twoStats(body,statCard("Transakcje",""+trades.length(),"Wszystkie pozycje",white),statCard("Wygrane / przegrane",wins+" / "+loss,"Zamknięte wyniki",white));
    LinearLayout chart=card(body);label(chart,"KRZYWA KAPITAŁU",12,muted,true);gap(chart,8);add(chart,new EquityChart(this));
    gap(body,7);button(body,"＋   DODAJ TRANSAKCJĘ",()->edit(-1));gap(body,18);
    label(body,"OSTATNIE TRANSAKCJE",12,muted,true);gap(body,12);
    if(trades.length()==0)label(body,"Brak transakcji. Zacznij od dodania pierwszej pozycji.",13,muted,false);
    for(int i=trades.length()-1;i>=Math.max(0,trades.length()-3);i--){JSONObject j=trades.optJSONObject(i);if(j!=null)tradeCard(body,j,i);}
  }
  void tradeCard(LinearLayout parent,JSONObject j,int idx){
    LinearLayout c=col();pad(c,15);c.setBackground(outlined(panel,17));marginBottom(parent,c,10);
    LinearLayout top=row();add(c,top);TextView name=txt(j.optString("symbol","—"),17,white,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));boolean isLong=j.optString("direction", "Long").toLowerCase().contains("long");add(top,chip(isLong?"▲ LONG":"▼ SHORT",isLong?green:red,isLong?0xff123d36:0xff492436));gap(c,8);
    LinearLayout bottom=row();add(c,bottom);TextView date=txt(j.optString("date",""),11,muted,false);bottom.addView(date,new LinearLayout.LayoutParams(0,-2,1));add(bottom,txt(money(val(j,"pnl")),17,val(j,"pnl")>=0?green:red,true));c.setOnClickListener(v->edit(idx));
  }
  class EquityChart extends View{
    Paint p=new Paint(3);EquityChart(Context c){super(c);setMinimumHeight(dp(190));}
    protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),dp(190));}
    protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();p.setColor(0xff31506c);p.setStrokeWidth(dp(1));for(int i=1;i<4;i++)c.drawLine(0,h*i/4f,w,h*i/4f,p);
      ArrayList<Double> values=new ArrayList<>();values.add(0.0);double sum=0,min=0,max=0;
      for(int i=0;i<trades.length();i++){JSONObject j=trades.optJSONObject(i);if(j!=null)sum+=val(j,"pnl");values.add(sum);min=Math.min(min,sum);max=Math.max(max,sum);}
      if(values.size()<2)return;p.setColor(0xff55b9ff);p.setStrokeWidth(dp(3));p.setStyle(Paint.Style.STROKE);
      Path path=new Path();for(int i=0;i<values.size();i++){float x=dp(5)+(w-dp(10))*i/(values.size()-1f);float y=dp(12)+(h-dp(24))*(float)((max-values.get(i))/(max-min==0?1:max-min));if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
    }
  }
  void journal(){sectionTitle(body,"Dziennik transakcji","Historia Twoich pozycji i decyzji");button(body,"＋   NOWA TRANSAKCJA",()->edit(-1));gap(body,20);
    if(trades.length()==0){LinearLayout empty=card(body);label(empty,"Jeszcze nie ma transakcji",17,white,true);gap(empty,8);label(empty,"Dodaj pierwszą pozycję, aby rozpocząć analizę wyników.",13,muted,false);}
    for(int i=trades.length()-1;i>=0;i--){JSONObject j=trades.optJSONObject(i);if(j!=null)tradeCard(body,j,i);}
  }
  void analysis(){sectionTitle(body,"Analiza skuteczności","Poznaj swoje najmocniejsze setupy");HashMap<String,int[]> counts=new HashMap<>();
    for(int i=0;i<trades.length();i++){JSONObject j=trades.optJSONObject(i);if(j==null)continue;String s=j.optString("strategy","Inne");int[] c=counts.get(s);if(c==null){c=new int[2];counts.put(s,c);}c[0]++;if(val(j,"pnl")>0)c[1]++;}
    LinearLayout summary=card(body);label(summary,"SKUTECZNOŚĆ STRATEGII",12,muted,true);gap(summary,12);
    if(counts.isEmpty())label(summary,"Dodaj transakcje, aby zobaczyć analizę.",13,muted,false);
    for(String s:counts.keySet()){int[] c=counts.get(s);gap(summary,10);label(summary,s+"   "+c[1]+"/"+c[0]+"  ("+Math.round(c[1]*100.0/c[0])+"%)",14,white,false);gap(summary,7);ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(c[0]);p.setProgress(c[1]);add(summary,p);}
    LinearLayout info=card(body);label(info,"TWOJE WNIOSKI",12,muted,true);gap(info,10);label(info,"Wszystkie statystyki są liczone lokalnie na podstawie zapisanych transakcji.",13,white,false);
  }
  void more(){sectionTitle(body,"Centrum tradera","Psychologia, dane i ustawienia");LinearLayout c=card(body);label(c,"PSYCHOLOGIA TRADINGU",12,muted,true);gap(c,10);label(c,"Zapisuj emocje i ocenę decyzji w notatkach do każdej transakcji.",14,white,false);
    LinearLayout d=card(body);label(d,"KOPIA DANYCH",12,muted,true);gap(d,12);button(d,"EKSPORTUJ JSON",()->{Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TEXT,trades.toString());startActivity(Intent.createChooser(intent,"Eksportuj dziennik"));});gap(d,12);
    button(d,"IMPORTUJ JSON ZE SCHOWKA",()->{android.content.ClipboardManager cb=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);try{CharSequence t=cb.getPrimaryClip().getItemAt(0).coerceToText(this);JSONArray incoming=new JSONArray(t.toString());trades=incoming;save();show(3);Toast.makeText(this,"Zaimportowano dane",0).show();}catch(Exception ex){Toast.makeText(this,"Nieprawidłowy JSON w schowku",1).show();}});
    label(body,"CH.S Trading Journal  •  AlgoBrothers  •  v0.3",12,muted,false);
  }
  EditText field(LinearLayout l,String hint,String def,boolean numeric){gap(l,8);label(l,hint.toUpperCase(new Locale("pl","PL")),11,muted,true);EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(white);e.setHintTextColor(muted);e.setTextSize(15);e.setHint(hint);e.setText(def);e.setPadding(dp(13),dp(11),dp(13),dp(11));e.setBackground(outlined(panel,11));if(numeric)e.setInputType(8194|4096);add(l,e);return e;}
  double num(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception x){return 0;}}
  void edit(int index){JSONObject old=index>=0?trades.optJSONObject(index):new JSONObject();if(old==null)old=new JSONObject();final JSONObject j=old;
    ScrollView scroll=new ScrollView(this);LinearLayout l=col();pad(l,20);l.setBackgroundColor(bg);scroll.addView(l);
    label(l,"CH.S  /  ALGOBROTHERS",12,muted,true);gap(l,14);label(l,index<0?"Nowa transakcja":"Edytuj transakcję",27,white,true);gap(l,16);
    EditText symbol=field(l,"Instrument",j.optString("symbol","XAUUSD"),false);
    EditText dir=field(l,"Kierunek: Long / Short",j.optString("direction","Long"),false);
    EditText entry=field(l,"Wejście",j.optString("entry",""),true);
    EditText sl=field(l,"Stop Loss",j.optString("sl",""),true);
    EditText tp=field(l,"Take Profit",j.optString("tp",""),true);
    EditText volume=field(l,"Wielkość pozycji",j.optString("volume",""),true);
    EditText pnl=field(l,"Wynik netto (zł)",j.optString("pnl",""),true);
    EditText strategy=field(l,"Strategia / setup",j.optString("strategy","Breakout"),false);
    EditText emotion=field(l,"Emocje / psychologia",j.optString("emotion",""),false);
    EditText note=field(l,"Notatka",j.optString("note",""),false);
    gap(l,16);button(l,"Zapisz transakcję",()->{try{
      j.put("symbol",symbol.getText().toString());j.put("direction",dir.getText().toString());j.put("entry",entry.getText().toString());j.put("sl",sl.getText().toString());j.put("tp",tp.getText().toString());j.put("volume",volume.getText().toString());j.put("pnl",num(pnl));j.put("strategy",strategy.getText().toString());j.put("emotion",emotion.getText().toString());j.put("note",note.getText().toString());
      if(index<0){j.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));trades.put(j);}else{trades.put(index,j);}save();show(1);
    }catch(Exception ex){Toast.makeText(this,"Błąd zapisu",1).show();}});
    if(index>=0){gap(l,10);button(l,"Usuń transakcję",()->{JSONArray next=new JSONArray();for(int i=0;i<trades.length();i++)if(i!=index)next.put(trades.opt(i));trades=next;save();show(1);});}
    gap(l,20);button(l,"Anuluj",()->show(1));setContentView(scroll);
  }
  @Override public void onBackPressed(){show(0);}
}
