# CH.S Trading Journal v0.3 — AlgoBrothers

Przebudowany ciemny interfejs Android: granatowe panele, gradientowy hero P&L, siatka statystyk, wykres, karty transakcji, nawigacja dolna, stylizowane formularze.

## Instalacja / build
1. Rozpakuj ZIP.
2. Prześlij **zawartość folderu** do głównego katalogu repozytorium GitHub, zachowując `.github/workflows/build-apk.yml`.
3. GitHub Actions → Build CHS Trading Journal APK → Run workflow.
4. Pobierz artefakt APK i zainstaluj.

Dane są zapisywane lokalnie w SharedPreferences. Aplikacja nie zawiera synchronizacji MT5. Przed zmianą lub reinstalacją aplikacji wyeksportuj dane z zakładki Więcej.

**Uwaga:** jest to projekt źródłowy gotowy do uruchomienia procesu kompilacji, nie zweryfikowany na fizycznym telefonie.
