package pl.algobrothers.chsjournal;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
  final int bg=Color.rgb(8,18,32), panel=Color.rgb(17,35,55), blue=Color.rgb(38,121,222), white=Color.WHITE, muted=Color.rgb(157,181,207), green=Color.rgb(36,213,137), red=Color.rgb(249,94,108);
  LinearLayout root,body,nav; JSONArray trades=new JSONArray(); int screen=0;
  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);load();show(0);}
  void load(){try{trades=new JSONArray(getPreferences(0).getString("trades","[]"));}catch(Exception e){trades=new JSONArray();}}
  void save(){getPreferences(0).edit().putString("trades",trades.toString()).apply();}
  GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  void add(LinearLayout l,View v){l.addView(v);}
  void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
  void label(LinearLayout l,String s,int size,int color,boolean bold){add(l,txt(s,size,color,bold));}
  LinearLayout card(LinearLayout parent){LinearLayout c=col();pad(c,16);c.setBackground(shape(panel,15));add(parent,c);gap(parent,12);return c;}
  void button(LinearLayout parent,String s,Runnable action){TextView b=txt(s,15,white,true);b.setGravity(Gravity.CENTER);pad(b,14);b.setBackground(shape(blue,12));add(parent,b);b.setOnClickListener(v->action.run());}
  double val(JSONObject j,String k){return j.optDouble(k,0);}
  String money(double n){return String.format(new Locale("pl","PL"),"%+.2f zł",n);}
  void show(int tab){
    screen=tab;root=col();root.setBackgroundColor(bg);setContentView(root);
    LinearLayout head=col();pad(head,18);add(root,head);
    label(head,"↗  CH.S",29,white,true);label(head,"T R A D I N G   J O U R N A L",10,muted,false);
    gap(head,13);
    body=col();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));pad(body,16);
    if(tab==0)dashboard();else if(tab==1)journal();else if(tab==2)analysis();else more();
    nav=row();pad(nav,9);nav.setBackgroundColor(panel);add(root,nav);
    String[] names={"⌂  Pulpit","▤  Dziennik","▥  Analiza","☰  Więcej"};
    for(int i=0;i<4;i++){final int ix=i;TextView n=txt(names[i],12,i==tab?white:muted,i==tab);n.setGravity(Gravity.CENTER);nav.addView(n,new LinearLayout.LayoutParams(0,dp(45),1));n.setOnClickListener(v->show(ix));}
  }
  void dashboard(){
    label(body,"Dashboard",22,white,true);gap(body,14);
    int wins=0,loss=0;double total=0,grossWin=0,grossLoss=0;
    for(int i=0;i<trades.length();i++){JSONObject j=trades.optJSONObject(i);if(j==null)continue;double p=val(j,"pnl");total+=p;if(p>0){wins++;grossWin+=p;}if(p<0){loss++;grossLoss-=p;}}
    LinearLayout a=card(body);label(a,"Wynik (P&L)",13,muted,false);label(a,money(total),26,total>=0?green:red,true);
    LinearLayout b=card(body);label(b,"Win Rate",13,muted,false);label(b,(wins+loss==0?"—":String.format(Locale.US,"%.1f%%",100.0*wins/(wins+loss))),25,white,true);
    LinearLayout c=card(body);label(c,"Profit Factor",13,muted,false);label(c,grossLoss==0?"—":String.format(Locale.US,"%.2f",grossWin/grossLoss),24,white,true);
    LinearLayout d=card(body);label(d,"Liczba transakcji",13,muted,false);label(d,""+trades.length(),24,white,true);
    LinearLayout e=card(body);label(e,"Krzywa kapitału",16,white,true);add(e,new EquityChart(this));gap(body,5);
    button(body,"+ Dodaj transakcję",()->edit(-1));
  }
  class EquityChart extends View{
    Paint p=new Paint(3);EquityChart(Context c){super(c);setMinimumHeight(dp(190));}
    protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),dp(190));}
    protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();p.setColor(0xff31506c);p.setStrokeWidth(dp(1));for(int i=1;i<4;i++)c.drawLine(0,h*i/4f,w,h*i/4f,p);
      ArrayList<Double> values=new ArrayList<>();values.add(0.0);double sum=0,min=0,max=0;
      for(int i=0;i<trades.length();i++){JSONObject j=trades.optJSONObject(i);if(j!=null)sum+=val(j,"pnl");values.add(sum);min=Math.min(min,sum);max=Math.max(max,sum);}
      if(values.size()<2)return;p.setColor(0xff55b9ff);p.setStrokeWidth(dp(3));p.setStyle(Paint.Style.STROKE);
      Path path=new Path();for(int i=0;i<values.size();i++){float x=dp(5)+(w-dp(10))*i/(values.size()-1f);float y=dp(12)+(h-dp(24))*(float)((max-values.get(i))/(max-min==0?1:max-min));if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
    }
  }
  void journal(){label(body,"Dziennik transakcji",22,white,true);gap(body,12);button(body,"+ Nowa transakcja",()->edit(-1));gap(body,14);
    if(trades.length()==0)label(body,"Brak transakcji. Dodaj pierwszą pozycję.",14,muted,false);
    for(int i=trades.length()-1;i>=0;i--){final int idx=i;JSONObject j=trades.optJSONObject(i);if(j==null)continue;LinearLayout c=card(body);label(c,j.optString("symbol")+"  ·  "+j.optString("direction"),17,white,true);label(c,j.optString("date"),12,muted,false);label(c,money(val(j,"pnl")),20,val(j,"pnl")>=0?green:red,true);c.setOnClickListener(v->edit(idx));}
  }
  void analysis(){label(body,"Analiza",22,white,true);gap(body,12);HashMap<String,int[]> counts=new HashMap<>();
    for(int i=0;i<trades.length();i++){JSONObject j=trades.optJSONObject(i);if(j==null)continue;String s=j.optString("strategy","Inne");int[] c=counts.get(s);if(c==null){c=new int[2];counts.put(s,c);}c[0]++;if(val(j,"pnl")>0)c[1]++;}
    LinearLayout summary=card(body);label(summary,"Skuteczność strategii",17,white,true);
    if(counts.isEmpty())label(summary,"Dodaj transakcje, aby zobaczyć analizę.",13,muted,false);
    for(String s:counts.keySet()){int[] c=counts.get(s);gap(summary,10);label(summary,s+"   "+c[1]+"/"+c[0]+"  ("+Math.round(c[1]*100.0/c[0])+"%)",14,white,false);ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(c[0]);p.setProgress(c[1]);add(summary,p);}
    LinearLayout info=card(body);label(info,"Wnioski",17,white,true);label(info,"Statystyki liczone na podstawie zapisanych lokalnie transakcji.",13,muted,false);
  }
  void more(){label(body,"Więcej",22,white,true);gap(body,12);LinearLayout c=card(body);label(c,"Psychologia tradingu",17,white,true);label(c,"Notatki i emocje zapisujesz przy transakcji.",13,muted,false);
    LinearLayout d=card(body);label(d,"Kopia danych",17,white,true);gap(d,9);button(d,"Eksportuj JSON",()->{Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TEXT,trades.toString());startActivity(Intent.createChooser(intent,"Eksportuj dziennik"));});
    button(d,"Importuj JSON ze schowka",()->{android.content.ClipboardManager cb=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);try{CharSequence t=cb.getPrimaryClip().getItemAt(0).coerceToText(this);JSONArray incoming=new JSONArray(t.toString());trades=incoming;save();show(3);Toast.makeText(this,"Zaimportowano dane",0).show();}catch(Exception ex){Toast.makeText(this,"Nieprawidłowy JSON w schowku",1).show();}});
    label(body,"CH.S Trading Journal · AlgoBrothers · v0.2",12,muted,false);
  }
  EditText field(LinearLayout l,String hint,String def,boolean numeric){label(l,hint,12,muted,false);EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(white);e.setHintTextColor(muted);e.setTextSize(15);e.setHint(hint);e.setText(def);if(numeric)e.setInputType(8194|4096);add(l,e);return e;}
  double num(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception x){return 0;}}
  void edit(int index){JSONObject old=index>=0?trades.optJSONObject(index):new JSONObject();if(old==null)old=new JSONObject();final JSONObject j=old;
    ScrollView scroll=new ScrollView(this);LinearLayout l=col();pad(l,20);l.setBackgroundColor(bg);scroll.addView(l);
    label(l,index<0?"Nowa transakcja":"Edytuj transakcję",22,white,true);gap(l,10);
    EditText symbol=field(l,"Instrument",j.optString("symbol","XAUUSD"),false);
    EditText dir=field(l,"Kierunek: Long / Short",j.optString("direction","Long"),false);
    EditText entry=field(l,"Wejście",j.optString("entry",""),true);
    EditText sl=field(l,"Stop Loss",j.optString("sl",""),true);
    EditText tp=field(l,"Take Profit",j.optString("tp",""),true);
    EditText volume=field(l,"Wielkość pozycji",j.optString("volume",""),true);
    EditText pnl=field(l,"Wynik netto (zł)",j.optString("pnl",""),true);
    EditText strategy=field(l,"Strategia / setup",j.optString("strategy","Breakout"),false);
    EditText emotion=field(l,"Emocje / psychologia",j.optString("emotion",""),false);
    EditText note=field(l,"Notatka",j.optString("note",""),false);
    gap(l,16);button(l,"Zapisz transakcję",()->{try{
      j.put("symbol",symbol.getText().toString());j.put("direction",dir.getText().toString());j.put("entry",entry.getText().toString());j.put("sl",sl.getText().toString());j.put("tp",tp.getText().toString());j.put("volume",volume.getText().toString());j.put("pnl",num(pnl));j.put("strategy",strategy.getText().toString());j.put("emotion",emotion.getText().toString());j.put("note",note.getText().toString());
      if(index<0){j.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));trades.put(j);}else{trades.put(index,j);}save();show(1);
    }catch(Exception ex){Toast.makeText(this,"Błąd zapisu",1).show();}});
    if(index>=0){gap(l,10);button(l,"Usuń transakcję",()->{JSONArray next=new JSONArray();for(int i=0;i<trades.length();i++)if(i!=index)next.put(trades.opt(i));trades=next;save();show(1);});}
    gap(l,20);button(l,"Anuluj",()->show(1));setContentView(scroll);
  }
  @Override public void onBackPressed(){show(0);}
}
