# CH.S Trading Journal — AlgoBrothers v0.2
Projekt Android Java, bez zewnętrznych bibliotek aplikacji.
Ekrany: Dashboard, Dziennik, Analiza, Więcej. Lokalny zapis transakcji w SharedPreferences.
Synchronizacja MT5 nie jest częścią tej wersji.
## Budowanie
Wgraj **rozpakowaną zawartość** tego ZIP do głównego katalogu repozytorium GitHub (zachowaj folder `.github`).
Actions → Build CHS Trading Journal APK → Run workflow.
Po udanym buildzie pobierz artefakt CHS_Trading_Journal_v2_APK, rozpakuj i zainstaluj app-debug.apk.
Uwaga: APK jest debugowy, nie jest podpisaną wersją produkcyjną. Nie testowano instalacji w tym środowisku.
